/*******************************

HEADER FILE FOR EEPROM_RW.C

********************************/
#include <stdbool.h>
#include <stdint.h>

#define PAGE_SIZE	32
#define EEPROM_SIZE 8192

FILE* controlByte(char *eepromFilename, char *opcode);

bool hw_readPage(unsigned char* buf, FILE *fh);

bool hw_writePage(unsigned char* buf, FILE *fh);

bool eeprom_read(uint32_t offset, int size, char* buf);

bool eeprom_write(uint32_t offset, int size, char *buf);
