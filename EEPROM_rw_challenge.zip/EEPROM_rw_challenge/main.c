/*****************************************************************
EEPROM READ/WRITE TEST CODE


11/10/20		MW			Creation

*******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "eeprom_rw.h"


//TEST 1 - read a few pages from an offset into a read buffer
bool test1(void) {
    //create a buffer to check with what is actually stored in the file
	unsigned char check_buf[96];

	FILE *check_fh = fopen("eeprom_ex.txt", "rb+");
	fseek(check_fh, 35, SEEK_SET);
	fread(&check_buf, sizeof(char), 96, check_fh);
	fclose(check_fh);

	//Perform eeprom_read operation: read 3 pages starting at offset 35 bytes
	unsigned char readbuf[96];
	unsigned char *readbuf_ptr = &readbuf[0];


	bool success = eeprom_read(35, 96, readbuf_ptr);
	if (!success) {
        printf("TEST 1 FAIL\n");
	}
	printf("read data: ");
	for (int i = 0; i < 96; i++) {
        printf("%x ", *readbuf_ptr);
		if (*readbuf_ptr != check_buf[i]) {
            printf("TEST 1 CHECK BUFFERS FAIL\n");
            return false;
		}
		readbuf_ptr++;
	}
	printf("\n");
    return true;
}

//TEST 2 - write a few bytes to the file from the start of the device
bool test2() {
    unsigned char buf[] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
                  0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
                  0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
                  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
                  0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
                  0x1b, 0x1c, 0x1d, 0x1e, 0x1f};
	unsigned char *buf_ptr = &buf[0];

	bool success = eeprom_write(32, sizeof(buf), buf_ptr);

	//read from the file to make sure it was written correctly
	unsigned char check_buf[96];
	FILE *check_fh = fopen("eeprom_ex.txt", "rb+");
	fseek(check_fh, 32, SEEK_SET);
	fread(&check_buf, sizeof(char), 64, check_fh);
	fclose(check_fh);

	if (!success) {
        printf("TEST 2 FAIL\n");
	}
    printf("read data: ");
	for (int i = 0; i < 64; i++) {
        printf("%x ", check_buf[i]);
        if (check_buf[i] != buf[i]) {
            printf("TEST 2 CHECK BUFFERS FAIL\n");
            return false;
        }
	}
	printf("\n");
    return true;
}

//TEST 3: Commanding OpCode 0xFF to erase eeprom, then test writing
bool test3(void) {
    FILE *test = controlByte("eeprom_ex.txt", "0xFF");
	if (test == NULL) {
        printf("TEST 3 ERASE FAIL\n");
	}

	//Write to file after erasing
	unsigned char buf[] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
                  0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
                  0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
                  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
                  0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
                  0x1b, 0x1c, 0x1d, 0x1e, 0x1f};

	bool success = eeprom_write(32, sizeof(buf), buf);

	//buffer to check that data was written correctly
	unsigned char check_buf[96];
	FILE *check_fh = fopen("eeprom_ex.txt", "rb+");
	fseek(check_fh, 32, SEEK_SET);
	fread(&check_buf, sizeof(char), 64, check_fh);
	fclose(check_fh);

	if (!success) {
        printf("TEST 3 WRITE FAIL\n");
	}
	printf("read data: ");
	for (int i = 0; i < 64; i++) {
        printf("%x ", check_buf[i]);
        if (check_buf[i] != buf[i]) {
            printf("TEST 3 CHECK BUFFERS FAIL\n");
            return false;
        }
	}
	printf("\n");
	return true;
}


//TEST 4: reading from an erased file
bool test4(void) {
	FILE *test = controlByte("eeprom_ex.txt", "0xFF");
	if (test == NULL) {
        printf("TEST 4 ERASE FAIL\n");
	}

	unsigned char* readbuf4 = (unsigned char *)malloc(sizeof(char)*96);
	bool success = eeprom_read(35, 96, readbuf4);
    //Should not be able to read from erased file
	if (success) {
        return false;
	}
	else {
        return true;
	}
}

//TEST 5: See error return if you read beyond the eeprom size
bool test5(void) {
    //See error return if you write beyond the eeprom size
	unsigned char buf[] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
                  0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
                  0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
                  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
                  0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
                  0x1b, 0x1c, 0x1d, 0x1e, 0x1f};
	unsigned char *buf_ptr = &buf[0];
	bool success = eeprom_write(8170, sizeof(buf), buf_ptr);
	if (success) {
        return false;
	}
	else {
        return true;
	}
}

int main(void)
{
    bool res;

    //Test 1
    res = test1();
    if (res) {
        printf("****************TEST 1 PASS****************\n");
    }
    else {
        printf("****************TEST 1 FAIL****************\n");
    }

    //Test 2
    res = test2();
    if (res) {
        printf("****************TEST 2 PASS****************\n");
    }
    else {
        printf("****************TEST 2 FAIL****************\n");
    }

    //Test 3
    res = test3();
    if (res) {
        printf("****************TEST 3 PASS****************\n");
    }
    else {
        printf("****************TEST 3 FAIL****************\n");
    }

    //Test 4
    res = test4();
    if (res) {
        printf("****************TEST 4 PASS****************\n");
    }
    else {
        printf("****************TEST 4 FAIL****************\n");
    }

    //Test 5
    res = test5();
    if (res) {
        printf("****************TEST 5 PASS****************\n");
    }
    else {
        printf("****************TEST 5 FAIL****************\n");
    }

	return 0;
}
