/*****************************************************************
EEPROM READ AND WRITE

2 Wire Serial EEPROM

Description: This file contains the functions that mimic reading and writing
			 to an EEPROM with a 32 byte page access. It assumes a procedure
			 for a typical EEPROM serial protocol, which accesses the EEPROM
             in 3 phases: OpCode, Address, and Data. The user can select the
             mode using the ControlByte() function. It is assumed that the
             EEPROM has a recommended page access of 32 bytes. The
             functions mimicking a page access are hw_readPage() and
             hw_writePage(). Finally, functions eeprom_read() and eeprom_write()
             utilize these hardware functions to read and write any valid size
             of data from any valid offset.

11/08/20		MW			Creation

*******************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "eeprom_rw.h"

//Resource Flag - Marks when EEPROM is busy
bool inUse = false;



//HARDWARE SIMULATING FUNCTIONS

/***********************************************************
* Function: controlByte
* ---------------------------------------
* Description: Hardware function for sending OpCode for EEPROM
*              operation. This function mimics the OpCode phase,
*              which selects the eeprom device (eeprom file)
*              (and selects the mode of operation (erase, read,
*              write).
*
* Inputs: char eepromFilename - filename for selected eeprom
*		  char rw			  - "r" OpCode for read operation
*								"w" OpCode for write operation
*                               "0xFF" OpCode for eeprom erase
*
* Returns: FILE* fh - file handle to eeprom file
*
************************************************************/
FILE* controlByte(char *eepromFilename, char *opcode) {
	FILE *fh;
	if (strcmp(opcode, "r") == 0) {
		//read mode
		fh = fopen(eepromFilename, "rb+");
	}
	else if (strcmp(opcode, "w") == 0) {
		//write mode
		fh = fopen(eepromFilename, "rb+");
	}
	else if (strcmp(opcode, "0xFF") == 0) {
        //erase eeprom
        fh = fopen(eepromFilename, "w");
	}
	else {
        return NULL;
	}
	return fh;
}


/***********************************************************
* Function: hw_readPage
* ---------------------------------------
* Description: Hardware function to read a 32 byte page from the
*              EEPROM
* Inputs: char *buf	- pointer to buffer to store read elements
*					  from one page access (32 bytes)
*         FILE *fh - File handle of eeprom device
*
* Returns: bool - true if page was read successfully
*				  false if error in reading page
*
************************************************************/
bool hw_readPage(unsigned char *buf, FILE *fh)
{

	//check if there is 32 bytes left in file to read
    if (ftell(fh) + PAGE_SIZE > EEPROM_SIZE) {
        printf("ERROR: Not enough space to read another page\n");
        return false;
    }
    else {
        size_t n = fread(buf, sizeof(char), PAGE_SIZE, fh);
        if (n != PAGE_SIZE) {
            printf("ERROR: Page read failed, n = %d\n", n);
            return false;
        }
    }
	return true;
}

/***********************************************************
* Function: hw_writePage
* ---------------------------------------
* Description: Hardware function to write a 32 byte page to the
*              EEPROM
* Inputs: char *buf	- pointer to buffer containing page of
*					  data to write from
*         FILE *fh - File handle of eeprom device
*
* Returns: bool - true if page was written successfully
*				  false if error in writing page
*
************************************************************/
bool hw_writePage(unsigned char *buf, FILE *fh)
{
    //check if there is 32 bytes left in file to write
    if (ftell(fh) + PAGE_SIZE > EEPROM_SIZE) {
        printf("ERROR: Not enough space to write another page\n");
        return false;
    }
    else {
        size_t n = fwrite(buf, sizeof(char), PAGE_SIZE, fh);

        if (n != PAGE_SIZE) {
            printf("ERROR: Page write failed, n = %d\n", n);
        }
    }

	return true;
}


/***********************************************************
* Function: eeprom_read
* ---------------------------------------
* Description: Reads size number of bytes from the eeprom
* starting from offset and returns the data in the given
* buffer
*
* Inputs: uint32_t offset - offset (in bytes) from start of
*							eeprom to begin reading from
*		  int size		  - size (in bytes) of data to read from eeprom
*		  char *buf	      - pointer to buffer to hold read page data
*
* Returns: bool - true if page was written successfully
*				  false if error in writing page
*
************************************************************/
bool eeprom_read(uint32_t offset, int size, unsigned char* buf)
{
    if (inUse) {
        printf("ERROR: EEPROM in use\n");
    }
    else {
        inUse = true;   //Mark device as busy

        //Check if read is within the size of the eeprom
        if (offset + size > EEPROM_SIZE) {
            printf("ERROR: Offset + size is greater than size of the EEPROM\n");
            inUse = false;  //Mark device as ready
            return false;
        }

        //Send control byte selecting device (filename) and read mode (OpCode "r")
        FILE *read_eeprom = controlByte("eeprom_ex.txt", "r");

        if (read_eeprom == NULL) {
            inUse = false;  //Mark device as ready
            return false;
        }
        else {
            //set address according to offset
            if (fseek(read_eeprom, offset, SEEK_SET)) {
                printf("ERROR: Could not reach offset\n");
                inUse = false;  //Mark device as ready
                return false;
            }
            //read from offset
            for (int i = 0; i < (size / PAGE_SIZE); i++) {
                if (!hw_readPage(buf, read_eeprom)) {
                    inUse = false;  //Mark device as ready
                    return false;
                }
                else {
                    buf += PAGE_SIZE;
                }
            }
            for (int i = 0; i < (size % PAGE_SIZE); i++) {
                *buf = fgetc(read_eeprom);
                if (*buf == EOF) {
                    inUse = false;  //Mark device as ready
                    return false;
                }
                buf++;
            }
        }
        fclose(read_eeprom);
        inUse = false;  //Mark device as ready
    }
	return true;
}

/***********************************************************
* Function: eeprom_write
* ---------------------------------------
* Description: Writes size number of bytes to the eeprom
* starting from offset from the data in the given
* buffer
*
* Inputs: uint32_t offset - offset (in bytes) from start of
*							eeprom to begin reading from
*		  int size		  - size (in bytes) of data to write to eeprom
*		  char *buf	      - pointer to buffer containing page of
*					        data to write from
*
* Returns: bool - true if page was written successfully
*				  false if error in writing page
*
************************************************************/
bool eeprom_write(uint32_t offset, int size, unsigned char *buf) {

     if (inUse) {
        printf("ERROR: EEPROM in use\n");
    }
    else {
        inUse = true;   //Mark device as busy
        //Check if write is within the size of the eeprom
        if (offset + size > EEPROM_SIZE) {
            printf("ERROR: Offset + size is greater than size of the EEPROM\n");
            inUse = false;  //Mark device as ready
            return false;
        }

        //Send control byte selecting device and write mode
        /*FILE *write_eeprom = fopen("eeprom_ex.txt", "rb+");*/
        //Send control byte selecting device (filename) and read mode (OpCode "r")
        FILE *write_eeprom = controlByte("eeprom_ex.txt", "w");

        if (write_eeprom == NULL) {
            inUse = false;  //Mark device as ready
            return false;
        }
        else {
            //set address according to offset
            if (fseek(write_eeprom, offset, SEEK_SET)) {
                printf("ERROR: Could not reach offset\n");
                inUse = false;  //Mark device as ready
                return false;
            }
            //write to offset
            for (int i = 0; i < (size / PAGE_SIZE); i++) {
                if (!hw_writePage(buf, write_eeprom)) {
                    inUse = false;  //Mark device as ready
                    return false;
                }
                else {
                    buf += PAGE_SIZE;
                }
            }
            //write remaining bytes
            size_t n = fwrite(buf, sizeof(char), (size % PAGE_SIZE), write_eeprom);
            if (n != (size % PAGE_SIZE)) {
                printf("ERROR: Could not write sub page data\n");
                inUse = false;  //Mark device as ready
                return false;
            }
        }
        fclose(write_eeprom);
        inUse = false;
    }
	return true;
}
