********EEPROM READ WRITE CODING CHALLENGE*********
Nov 11, 2020

This project contains my submission for the Cerebras EEPROM read/write coding assignment. It contains the following:
	>>Source
		-eeprom_rw.c: contains function definitions for read_eeprom(), write_eeprom() and additional helper 			      functions
		-eeprom_rw.h: contains function declarations for eeprom_rw functions
		-main:	      contains test functions that verifies functionality of the eeprom read/write operation
	>>bin
		-eeprom_rw.exe: executable which runs test cases for the project
		-eeprom_ex.txt: .txt file which represents the eeprom data. Please view this using the hex editor plugin 		for Notepad++
	
This directory also contains an extra copy of the eeprom_ex.txt as the other copy will be modified throughout the tests

To run the test, run the executable found in ..\EEPROM_rw_challenge\bin\eeprom_rw.exe
	
